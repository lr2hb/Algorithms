from flask import Flask, render_template, request
from werkzeug import secure_filename
import os
import subprocess

app = Flask(__name__)

@app.route('/upload')
def upload_file():
       return render_template('upload.html')

@app.route('/uploader', methods = ['GET', 'POST'])
def uploader():
    if request.method == 'POST':
        f = request.files['file']
        f.save(secure_filename(f.filename))
        subprocess.call("rm -f ./a.out", shell=True)
        retcode = subprocess.call("./test.sh", shell=True)
        return "<center><h1><big><big>Results:</big></big></h1><b><big><big><big> Your code passed " + str(retcode) + "/2 tests.</big></big></big></center></b>"

if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0')
