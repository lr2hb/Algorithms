package main
import "fmt"
func main() {
 var i int
 fmt.Print("Enter a number:")
 fmt.Scanf("%d", &i)
 
 var j int
 fmt.Print("Enter a number:")
 fmt.Scanf("%d", &j)

 fmt.Println(i + j)
}